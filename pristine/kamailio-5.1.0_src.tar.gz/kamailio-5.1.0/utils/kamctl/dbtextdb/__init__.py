#!/usr/bin/python
#
# Copyright 2008 Google Inc. All Rights Reserved.

"""Empty __init__ for dbtextdb module.

This file is empty, it only exists to enable importing dbtextdb
"""

__author__ = 'herman@google.com (Herman Sheremetyev)'
